#David Potters
#09/02/2019

def FileList(filename):
    list_return = []
    with open(filename) as f:
            line =  f.readline()
            while line:
                list_return.append(int(line))
                line = f.readline()

    return list_return

primeslist = FileList('primenumbers.txt')
happylist = FileList('happynumbers.txt')

overlaplist = [elem for elem in primeslist if elem in happylist]
print('The overlapping numbers in both files are: '+str(overlaplist))