#David Potters
#09/0202019
import sys

#Assigns input to word
Word = input('Please enter a word: ')
#Sets empty string to Palindrome
Palindrome = ""
#Loops through word and assigned Palindrome
for i in Word:
    Palindrome = i + Palindrome
print(Palindrome)

#Determines if palindrome or not
if(Word == Palindrome):
    print("This is a palindrome")
else:
    print("This is not a palindrome ")