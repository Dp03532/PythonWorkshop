#lab 1
#David Potters
#09/02/2019

#fib function that assigns fib to list.
def fibonacci():
    fib = []
    num = int(input('How many numbers to generate: '))
    i = 1
    if num == 0:
        fib ==[]
    elif num == 1:
        fib ==[1]
    elif num == 2:
        fib == [1,1]
    elif num > 2:
        fib = [1,1]
        while i < num -1:
            fib.append(fib[i] + fib[i-1])
            i+=1
    return fib


list = fibonacci()
print('The fibonacci sequence is:')
for m in list:
    print( m , end =' ')
sum = sum(list)


print()
print("The sum for all numbers is: "+str(sum))